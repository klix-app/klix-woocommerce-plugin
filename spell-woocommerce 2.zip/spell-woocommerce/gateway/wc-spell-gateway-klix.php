<?php

class WC_Spell_Gateway_Klix extends WC_Spell_Gateway_Abstract
{
    public $id = 'klix-payments';
}
