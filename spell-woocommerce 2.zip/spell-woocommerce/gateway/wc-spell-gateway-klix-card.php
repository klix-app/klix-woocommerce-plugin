<?php

class WC_Spell_Gateway_Klix_Card extends WC_Spell_Gateway_Abstract
{
    public $id = 'klix_card';

}
