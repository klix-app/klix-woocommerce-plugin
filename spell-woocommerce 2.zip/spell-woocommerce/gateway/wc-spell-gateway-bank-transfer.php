<?php

class WC_Spell_Gateway_Bank_Transfer extends WC_Spell_Gateway_Abstract
{
    public $id = 'bank_transfer';
}
