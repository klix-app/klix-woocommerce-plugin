<?php

class WC_Spell_Gateway extends WC_Spell_Gateway_Abstract
{
}
