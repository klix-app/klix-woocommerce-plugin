<?php

class WC_Spell_Gateway_Klix_Pay_Later extends WC_Spell_Gateway_Abstract
{
    public $id = 'klix_pay_later';
}
