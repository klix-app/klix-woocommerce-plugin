This module adds "Klix" API payment method option to your WordPress-based WooCommerce shop.

To install it, copy the `spell-woocommerce` directory (the one this file is in) into `wp-content/plugins` folder of your WooCommerce installation. 

Alternatively, if your setup allows that, you can use Plugin Installer and simply upload the archive.